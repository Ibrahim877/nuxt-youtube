const middleware = {}

middleware['Admin'] = require('..\\middleware\\Admin.js')
middleware['Admin'] = middleware['Admin'].default || middleware['Admin']

middleware['User'] = require('..\\middleware\\User.js')
middleware['User'] = middleware['User'].default || middleware['User']

export default middleware
