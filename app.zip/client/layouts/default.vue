<script>
  export default {
    data() {
      return {
        site: process.env.site
      }
    }
  }
</script>
<template>
  <div>
    <header>
      <nuxt-link to="/" tag="a">
        {{site.title}}
      </nuxt-link>
    </header>
    <Nuxt/>
  </div>
</template>
<style>
  * {
    margin: 0;
    padding: 0;
    border: none;
    box-sizing: border-box;
    list-style: none;
    text-decoration: none;
  }

  body {
    font-family: 'Roboto', sans-serif;
    background: #181924;
    color: #fff
  }

  .card {
    box-shadow: 0 1px 1px 0 rgba(0, 0, 0, .14), 0 2px 1px -1px rgba(0, 0, 0, .12), 0 1px 3px 0 rgba(0, 0, 0, .2);
    background: #24252F;
  }

  .border-primary {
    border-color: #4638c2 !important;
  }

  header {
    background: #4638c2;
    color: #fff;
    height: 50px;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  header a {
    color: #fff;
    font-weight: bold;
    font-size: 18px;
  }

  header a:hover {
    color: #fff
  }

  ul.nav {
    border-bottom: 1px solid rgba(0, 0, 0, 0.125);
  }

  ul.nav li a {
    color: #fff !important;
  }

  ul.nav li a.active {
    background: #4638c2 !important;
    border: none !important;
  }

  ul.list-group, ul li.list-group-item {
    background: transparent;
  }

  .btn-outline-primary {
    border-color: #4638c2;
    color: #4638c2
  }
  .btn-outline-primary:hover{
    background: #4638c2;
  }
</style>
