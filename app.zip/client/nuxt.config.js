let assets = 'http://localhost/youtube/client/assets/'
export default {
  /*
  ** Nuxt rendering mode
  ** See https://nuxtjs.org/api/configuration-mode
  */
  mode: 'universal',
  /*
  ** Nuxt target
  ** See https://nuxtjs.org/api/configuration-target
  */
  target: 'server/',
  /*
  ** Headers of the page
  ** See https://nuxtjs.org/api/configuration-head
  */
  head: {
    title: process.env.npm_package_name || '',
    meta: [
      {charset: 'utf-8'},
      {name: 'viewport', content: 'width=device-width, initial-scale=1'},
      {hid: 'description', name: 'description', content: process.env.npm_package_description || ''}
    ],
    link: [
      {rel: 'icon', type: 'image/x-icon', href: '/favicon.ico'},
      {
        rel: 'stylesheet',
        href: 'https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;0,900;1,400;1,500&display=swap'
      },
      {rel: 'stylesheet', href: assets + 'bootstrap/css/bootstrap.min.css'}
    ],
    script: [
      {src: assets + 'jquery/jquery.js'},
      {src: assets + 'jquery/popper.js'},
      {src: assets + 'bootstrap/js/bootstrap.bundle.min.js'},
      {src: 'https://kit.fontawesome.com/17dcf6ffcb.js'}
    ]
  },
  /*
  ** Global CSS
  */
  loading: {color: '#3b8070'},

  css: [],
  /*
  ** Plugins to load before mounting the App
  ** https://nuxtjs.org/guide/plugins
  */
  env: {
    api: 'http://localhost:3333/',
    assets: 'http://localhost/youtube/client/assets/',
    tokenKey: 'IbrAhIm-MaMMaDoV',
    site: {
      url: 'http://localhost:3000/',
      title: 'LocalHost'
    },
    youtube_api_key: 'AIzaSyD7IGJMh4EYpbwiJUsmtfLpwNZbkXKNeJE',
    youtube_get_video: 'https://www.googleapis.com/youtube/v3/videos?part=id%2C+snippet&&key=AIzaSyD7IGJMh4EYpbwiJUsmtfLpwNZbkXKNeJE&id=',
    youtube_search_video: 'https://youtube.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=10&key=AIzaSyD7IGJMh4EYpbwiJUsmtfLpwNZbkXKNeJE&q='
  },

  plugins: [],
  /*
  ** Auto import components
  ** See https://nuxtjs.org/api/configuration-components
  */
  components: true,
  /*
  ** Nuxt.js dev-modules
  */
  buildModules: [],
  /*
  ** Nuxt.js modules
  */
  modules: [
    '@nuxtjs/axios',
    'nuxt-sweetalert2'
  ],
  /*
  ** Build configuration
  ** See https://nuxtjs.org/api/configuration-build/
  */
  // build: {
  //   publicPath: 'http://localhost/dist',
  // },
  // router: {
  //   base: '/dist/'
  // },

}
