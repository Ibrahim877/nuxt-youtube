<script>
  import {Base64} from 'js-base64';

  export default {
    head() {
      return {
        title: 'YouTube Video / Mp3 yüklə'
      }
    },
    data() {
      return {
        link: null,
        loading: false,
        video: {},
        hasVideo: false,
        api: process.env.api
      }
    },
    methods: {
      // getVideo() {
      //   this.hasVideo = false
      //   this.loading = true
      //   this.$axios.post(process.env.api + 'youtube/get', {
      //     link: this.link
      //   })
      //     .then(res => {
      //       const video = res.data.video.videoDetails
      //       this.video = {
      //         title: video.title,
      //         viewCount: video.viewCount,
      //         publishDate: video.publishDate,
      //         duration: new Date(video.lengthSeconds * 1000).toISOString().substr(11, 8),
      //         thumbnail: video.thumbnail.thumbnails[video.thumbnail.thumbnails.length - 1],
      //         videoUrl: video.video_url,
      //         videoId: video.videoId,
      //         hashTitle: Base64.encode(video.title),
      //         hashId: Base64.encode(video.videoId),
      //       }
      //       this.hasVideo = true
      //     })
      //     .catch(err => {
      //       console.log(err.toString())
      //     })
      //     .finally(() => {
      //       this.loading = false
      //     })
      // }
      getVideo() {
        const explode = this.link.split('watch?v=')
        const videoId = explode[1]
        this.hasVideo = false
        this.loading = true
        this.$axios.get(process.env.youtube_get_video + videoId)
          .then(res => {
            if (res.data.items.length > 0) {
              const item = res.data.items[0]
              console.log(item)
              this.video = {
                title: item.snippet.title,
                videoId: item.id,
                thumbnail: item.snippet.thumbnails.high,
                publishDate: item.snippet.publishedAt,
                hashTitle: Base64.encode(item.snippet.title),
                hashId: Base64.encode(item.id),
              }
              this.hasVideo = true
            } else {
              alert('Video tapılmadı')
            }
          })
          .catch(err => {
            console.log(err.toString())
          })
          .finally(() => {
            this.loading = false
          })
      }
    }
  }
</script>
<template>
  <div class="container mt-5">
    <!-- Preview -->
    <div class="modal fade" id="preview" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl">
        <div class="modal-content bg-dark">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">{{video.title}}</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <iframe :src="'https://www.youtube.com/embed/'+video.videoId" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen></iframe>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Bağla</button>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card border-primary">
          <ul class="nav nav-tabs">
            <li class="nav-item">
              <nuxt-link to="/" tag="a" class="nav-link active">Link</nuxt-link>
            </li>
            <li class="nav-item">
              <nuxt-link to="/search" tag="a" class="nav-link">Axtar</nuxt-link>
            </li>
          </ul>
          <div class="card-body">
            <form @submit.prevent="getVideo">
              <div class="form-group">
                <label for="video_link">Video Linki</label>
                <input type="url" id="video_link" v-model="link" placeholder="Video linkini daxil edin"
                       class="form-control" required>
              </div>
              <div class="form-group d-flex flex-row-reverse">
                <input type="submit" class="btn btn-sm btn-outline-primary" value="Axtar">
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <div class="row mt-3">
      <div class="col-12">
        <div v-if="loading" class="d-flex justify-content-center">
          <div class="spinner-border" role="status">
            <span class="sr-only">Loading...</span>
          </div>
        </div>
        <div v-else-if="hasVideo" class="card">
          <div class="card-header">
            {{video.title}}
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-12 col-lg-4">
                <img
                  :src="video.thumbnail.url"
                  alt="" class="img-fluid">
              </div>
              <div class="col-12 col-lg-8">
                <ul class="list-group">
                  <li class="list-group-item">
                    Başlıq : {{video.title}}
                  </li>
                  <li class="list-group-item">
                    Paylaşılıb : {{video.publishDate}}
                  </li>
                </ul>
                <div class="row mt-1">
                  <div class="col-4">
                    <a
                      :href="api+'youtube/mp4/'+video.hashId+'/'+video.hashTitle"
                      class="btn btn-sm btn-success btn-block">Mp4 Yüklə</a>
                  </div>
                  <div class="col-4">
                    <a
                      :href="api+'youtube/mp3/'+video.hashId+'/'+video.hashTitle"
                      class="btn btn-sm btn-info btn-block">Mp3 Yüklə</a>
                  </div>
                  <div class="col-4">
                    <a href="#" data-toggle="modal" data-target="#preview" class="btn btn-sm btn-warning btn-block">Canlı
                      bax</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<style>
  iframe {
    width: 100%;
    min-height: 60vh;
  }
</style>
