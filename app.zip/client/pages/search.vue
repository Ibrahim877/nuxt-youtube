<script>
  import {Base64} from 'js-base64';

  export default {
    head() {
      return {
        title: 'YouTube Video / Mp3 yüklə'
      }
    },
    data() {
      return {
        query: null,
        loading: false,
        video: {},
        hasVideo: false,
        items: [],
        api: process.env.api,
        selectedVideo: {
          videoId: null,
          title: null
        }
      }
    },
    methods: {
      getVideo() {
        this.hasVideo = false
        this.loading = true
        let api = process.env.youtube_search_video + this.query
        this.$axios.get(api)
          .then(res => {
            let items = []
            if (res.data.items.length > 0) {
              items = res.data.items
              items.forEach(item => {
                this.items.push({
                  title: item.snippet.title,
                  videoId: item.id.videoId,
                  thumbnail: item.snippet.thumbnails.high,
                  publishDate: item.snippet.publishedAt,
                  hashTitle: Base64.encode(item.snippet.title),
                  hashId: Base64.encode(item.id.videoId),
                })
              })
              this.hasVideo = true
            }
          })
          .catch(err => {
            console.log(err.toString())
          })
          .finally(() => {
            this.loading = false
          })
      }
    }
  }
</script>
<template>
  <div class="container mt-5">
    <!-- Preview -->
    <div class="modal fade" id="preview" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl">
        <div class="modal-content bg-dark">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">{{selectedVideo.title}}</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <iframe :src="'https://www.youtube.com/embed/'+selectedVideo.videoId" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen></iframe>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Bağla</button>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card border-primary">
          <ul class="nav nav-tabs">
            <li class="nav-item">
              <nuxt-link to="/" tag="a" class="nav-link">Link</nuxt-link>
            </li>
            <li class="nav-item">
              <nuxt-link to="/search" tag="a" class="nav-link active">Axtar</nuxt-link>
            </li>
          </ul>
          <div class="card-body">
            <form @submit.prevent="getVideo">
              <div class="form-group">
                <label for="query">Video başlığı</label>
                <input type="text" id="query" v-model="query" placeholder="Video başlığı"
                       class="form-control" required>
              </div>
              <div class="form-group d-flex flex-row-reverse">
                <input type="submit" class="btn btn-sm btn-outline-primary" value="Axtar">
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <div v-if="loading" class="d-flex justify-content-center mt-3">
      <div class="spinner-border" role="status">
        <span class="sr-only">Loading...</span>
      </div>
    </div>
    <div v-for="(item, index) in items" class="row mt-3">
      <div class="col-12">
        <div v-if="!loading && hasVideo" class="card">
          <div class="card-header">
            {{item.title}}
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-12 col-lg-4">
                <img
                  :src="item.thumbnail.url"
                  alt="" class="img-fluid">
              </div>
              <div class="col-12 col-lg-8">
                <ul class="list-group">
                  <li class="list-group-item">
                    Başlıq : {{item.title}}
                  </li>
                  <li class="list-group-item">
                    Paylaşılıb : {{item.publishDate}}
                  </li>
                </ul>
                <div class="row mt-1">
                  <div class="col-4">
                    <a
                      :href="api+'youtube/mp4/'+item.hashId+'/'+item.hashTitle"
                      class="btn btn-sm btn-success btn-block">Mp4 Yüklə</a>
                  </div>
                  <div class="col-4">
                    <a
                      :href="api+'youtube/mp3/'+item.hashId+'/'+item.hashTitle"
                      class="btn btn-sm btn-info btn-block">Mp3 Yüklə</a>
                  </div>
                  <div class="col-4">
                    <a href="#" @click.prevent="selectedVideo = item" data-toggle="modal" data-target="#preview"
                       class="btn btn-sm btn-warning btn-block">Canlı
                      bax</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<style>
  iframe {
    width: 100%;
    min-height: 60vh;
  }
</style>
