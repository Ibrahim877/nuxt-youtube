import hmacSHA512 from 'crypto-js/hmac-sha512';
import Base64 from 'crypto-js/enc-base64';

export default function ({store, redirect}) {
  const getUser = localStorage.getItem('user');

  if (getUser) {
    const user = JSON.parse(getUser);
    if (user.username && user.password) {
      const tokenKey = process.env.tokenKey;
      const userToken = Base64.stringify(hmacSHA512(user.username + user.password, tokenKey));

      if (userToken != user.token) {
        redirect('/user/login')
      }
    } else {
      redirect('/user/login')
    }
  } else {
    redirect('/user/login')
  }

}
