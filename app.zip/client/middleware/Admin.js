import hmacSHA512 from 'crypto-js/hmac-sha512';
import Base64 from 'crypto-js/enc-base64';

export default function ({store, redirect}) {
  const getAdmin = localStorage.getItem('admin');

  if (getAdmin) {
    const admin = JSON.parse(getAdmin);
    if (admin.username && admin.password) {
      const tokenKey = process.env.tokenKey;
      const adminToken = Base64.stringify(hmacSHA512(admin.username + admin.password, tokenKey));

      if (adminToken != admin.token) {
        redirect('/admin')
      }
    } else {
      redirect('/admin')
    }
  } else {
    redirect('/admin')
  }

}
