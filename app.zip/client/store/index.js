import Vuex from 'vuex'
import swal from 'sweetalert2'

const createStore = () => {
  return new Vuex.Store({
    state: () => ({}),
    mutations: {},
    actions: {},
    getters: {},
    modules: {}
  })
}

export default createStore
