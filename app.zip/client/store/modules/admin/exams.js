import swal from 'sweetalert2'

const exams = {
  state: {
    exams: [],
  },
  mutations: {
    updateExams(state, items) {
      state.exams = items
    },
    addExam(state, exam) {
      state.exams.push(exam)
    },
    updateExam(state, exam) {
      const examIndex = state.exams.findIndex(item => item.id === exam.id)
      if (examIndex > -1) {
        state.exams[examIndex] = exam
      }
    },
    delExam(state, id) {
      const examIndex = state.exams.findIndex(item => item.id === id)
      if (examIndex > -1) {
        state.exams.splice(examIndex, 1)
      }
    }
  },
  actions: {
    addExam(context, item) {
      return this.$axios.post(process.env.api + 'exams/add', item)
        .then(res => {
          if (res.data.success) {
            // context.commit('updateExams', res.data.items)
            context.commit('addExam', res.data.exam)
            swal.fire('Təbriklər !', res.data.success, 'success')
          } else if (res.data.error) {
            swal.fire('Xəta !', res.data.error, 'error')
          }
        })
        .catch(err => {
          swal.fire('Xəta !', err.toString(), 'error')
        })
    },
    updateExamStatus(context, item) {
      this.$axios.post(process.env.api + 'exams/update_exam_status', item)
        .then(res => {
          if (res.data.success) {
            context.commit('updateExam', res.data.exam)
          }
        })
    },
    editExam(context, item) {
      return this.$axios.post(process.env.api + 'exams/edit', item)
        .then(res => {
          if (res.data.success) {
            context.commit('updateExam', res.data.exam)
            swal.fire('Təbriklər !', res.data.success, 'success')
          } else if (res.data.error) {
            swal.fire('Xəta !', res.data.error, 'error')
          }
        })
        .catch(err => {
          swal.fire('Xəta !', err.toString(), 'error')
        })
    },
    delExam(context, id) {
      return this.$axios.post(process.env.api + 'exams/del', {
        id: id
      })
        .then(res => {
          if (res.data.success) {
            context.commit('delExam', id)
            swal.fire('Təbriklər !', res.data.success, 'success')
          } else if (res.data.error) {
            swal.fire('Xəta !', res.data.error, 'error')
          }
        })
        .catch(err => {
          swal.fire('Xəta !', err.toString(), 'error')
        })
    }
  },
  getters: {
    getAllExams(state) {
      state.exams.forEach(exam => {
        if (exam.status == '1') {
          exam.status = true
        } else {
          exam.status = false
        }
      })
      return state.exams;
    },
    getExam: (state) => (id) => {
      return state.exams.find(exam => exam.id === id);
    }
  }
}

export default exams
