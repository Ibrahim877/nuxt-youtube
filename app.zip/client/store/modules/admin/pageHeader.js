const pageHeader = {
    state: {
        pageHeader: {}
    },
    mutations: {
        setPageHeader(state, data) {
            state.pageHeader = data
        }
    },
    actions: {
        setPageHeader(context, data) {
            context.commit('setPageHeader', data)
        }
    },
    getters: {
        getPageHeader(state) {
            return state.pageHeader;
        }
    }
}

export default pageHeader
