import swal from 'sweetalert2'

const questions = {
  state: {
    questions: [],
    question: []
  },
  mutations: {
    updateQuestions(state, items) {
      if (items !== {}) {
        state.questions = items
      }
    },
    updateExamQuestions(state, data) {
      state.questions[data.examId] = data.items
    },
    delQuestion(state, data) {
      const questionIndex = state.questions[data.examId].findIndex(item => item.id === data.questionId)
      if (questionIndex > -1) {
        state.questions[data.examId].splice(questionIndex, 1)
      }
    },
  },
  actions: {
    addQuestions(context, formData) {
      return this.$axios.post(process.env.api + 'questions/add', formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        })
        .then(res => {
          if (res.data.success) {
            context.commit('updateExamQuestions', {
              examId: res.data.examId,
              items: res.data.items
            })
            swal.fire('Təbriklər !', res.data.success, 'success')
          } else if (res.data.error) {
            swal.fire('Xəta !', res.data.error, 'error')
          }
        })
        .catch(err => {
          swal.fire('Xəta !', err.toString(), 'error')
        })
    },
    questionsRankSave(context, items) {
      return this.$axios.post(process.env.api + 'questions/rankSave', items)
        .then(res => {
          if (res.data.success) {
            context.commit('updateQuestions', res.data.items)
          } else if (res.data.error) {
            swal.fire('Xəta !', res.data.error, 'error')
          }
        })
        .catch(err => {
          swal.fire('Xəta !', err.toString(), 'error')
        })
    },
    delQuestions(context, data) {
      return this.$axios.post(process.env.api + 'questions/del', data)
        .then(res => {
          if (res.data.success) {
            context.commit('delQuestion', {
              examId: data.examId,
              questionId: data.questionId
            })
            swal.fire('Təbriklər !', res.data.success, 'success')
          } else if (res.data.error) {
            swal.fire('Xəta !', res.data.error, 'error')
          }
        })
        .catch(err => {
          swal.fire('Xəta !', err.toString(), 'error')
        })
    }
  },
  getters: {
    getAllQuestions(state) {
      return state.questions;
    },
    getQuestions: (state) => (id) => {
      return state.questions[id];
    }
  }
}

export default questions
