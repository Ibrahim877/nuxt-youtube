const express = require('express')
const app = express();
const cors = require('cors')
const ytdl = require('ytdl-core')
const request = require('request');
const {spawn} = require('child_process');
const Base64 = require('js-base64')

app.use(cors())
app.use(express.json())


app.post('/youtube/get', async (req, res) => {
    const data = req.body.link
    const explode = data.split('watch?v=')
    const videoId = explode[1]
    const info = await ytdl.getInfo(videoId);
    res.status(200).json({
        video: info
    })
});

app.get('/youtube/mp4/:videoId/:videoTitle', async (req, res, next) => {
    const videoId = Base64.decode(req.params.videoId)
    const videoTitle = Base64.decode(req.params.videoTitle)
    try {
        /* response attachment for triggering download instead of stream */
        res.attachment(`${videoTitle}.mp4`);

        /*Downloading ,Converting mp4 youtube video using video_id  */
        const ytdl = spawn('youtube-dl', [
            '-o',//output
            '-',//stdout
            'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',//best mp4 extension , else best
            '--recode-video',//recode video
            'mp4',//to mp4 if not mp4
            '-a',//input stream
            '-'//stdin
        ])
            .on('error', (err) => next(err))
            .on('exit', (code) => console.log(`Ytdl exited with code ${code}`));

        /* Setting output pipe first so that we dont lose any bits */
        ytdl.stdout.pipe(res).on('error', (err) => next(err));

        /*Catching error on stdin */
        ytdl.stdin.on('error', (err) => next(err));

        /* Writing video url to stdin for youtube-dl */
        ytdl.stdin.write(`http://www.youtube.com/watch?v=${videoId}`)

        /*Closing the input stream; imp, else it waits */
        ytdl.stdin.end();


    } catch (error) {
        next(error);
    }
})

app.get('/youtube/mp3/:videoId/:videoTitle', async (req, res, next) => {
    const videoId = Base64.decode(req.params.videoId)
    const videoTitle = Base64.decode(req.params.videoTitle)

    try {
        /* response attachment for triggering download instead of stream */
        res.attachment(`${videoTitle}.mp3`);

        /* For Extracting mp3 from video stream of youtube-dl , on the fly(pipe) */
        let ffmpeg_child = spawn("ffmpeg", [
            '-i', //input
            'pipe:0', //stdin
            '-acodec', //audio codec
            'libmp3lame',//external encoding library
            '-f', //format
            'mp3',//mp3
            '-'//output to stdout
        ])
            .on('error', (err) => next(err))
            .on('exit', (code) => console.log(`Ffmpeg exited with code ${code}`));

        /*Catching Errors on stdin */
        ffmpeg_child.stdin.on('error', (err) => next(err));

        /* Setting output pipe first so that we dont lose any bits */
        ffmpeg_child.stdout.pipe(res).on('error', (err) => next(err));

        /* For Downloading video from youtube using video-id */
        const ytdl = spawn('youtube-dl', [
            '-o',//output
            '-',//stdout
            '-a',//input stream
            '-'//stdin
        ])
            .on('error', (err) => next(err))
            .on('exit', (code) => console.log(`Ytdl exited with code ${code}`));

        /* Setting output pipe first so that we dont lose any bits */
        ytdl.stdout.pipe(ffmpeg_child.stdin).on('error', (err) => next(err));

        /*Catching errors on stdin */
        ytdl.stdin.on('error', (err) => next(err));

        /* Writing video url to stdin for youtube-dl */
        ytdl.stdin.write(`http://www.youtube.com/watch?v=${videoId}`);

        /*Closing the input stream; imp, else it waits */
        ytdl.stdin.end();


    } catch (error) {
        next(err);
    }
})


app.listen(3333);